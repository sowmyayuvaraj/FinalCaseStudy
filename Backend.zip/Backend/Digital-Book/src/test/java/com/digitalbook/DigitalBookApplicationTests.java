package com.digitalbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
