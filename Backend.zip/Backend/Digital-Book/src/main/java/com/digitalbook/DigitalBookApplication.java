package com.digitalbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalBookApplication.class, args);
	}

}
