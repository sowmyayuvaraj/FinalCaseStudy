package com.digitalbook.Repository;

//import java.util.List;

import com.digitalbook.entity.DigitalBook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.digitalbook.entity.DigitalBook;

@Repository
public interface DigitalBookRepository extends JpaRepository<DigitalBook, Integer> {

	// List<Integer> findByUserId(Integer id);

}
