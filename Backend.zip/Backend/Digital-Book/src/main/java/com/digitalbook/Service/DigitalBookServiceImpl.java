package com.digitalbook.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.digitalbook.Service.DigitalBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalbook.entity.*;
import com.digitalbooks.Crud.Error.RecordNotFoundException;
import com.digitalbooks.Crud.Repository.DigitalBookRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class DigitalBookServiceImpl implements DigitalBookService {

	@Autowired
	DigitalBookRepository digitalBookRepository;

	@Override
	public DigitalBook saveDigitalBook(DigitalBook book) {
		return digitalBookRepository.save(book);

	}

	@Override
	public DigitalBook getDigitalBookById(int digitalBookId) {
		Optional<DigitalBook> digitalBookDb = digitalBookRepository.findById(digitalBookId);
		if (digitalBookDb.isPresent()) {
			return digitalBookDb.get();
		} else {
			throw new RecordNotFoundException("Record not found!!");
		}
	}

	@Override
	public List<DigitalBook> getAllDigitalBooks() {
		return digitalBookRepository.findAll();

	}

	@Override
	public List<DigitalBook> searchDigitalBooks(String title, String author, String category, Double price,
			String publisher) {

		List<DigitalBook> digitalBooks = digitalBookRepository.findAll();
		return digitalBooks.stream()
				.filter(book -> book.getTitle().equalsIgnoreCase(title) || book.getCategory().equalsIgnoreCase(category)
						|| book.getAuthor().equalsIgnoreCase(author) || book.getPrice().equals(price)
						|| book.getPublisher().equalsIgnoreCase(publisher))
				.collect(Collectors.toList());
	}

	@Override
	public List<DigitalBook> searchDigitalBookByTitle(String title) {
		List<DigitalBook> digitalBooks = digitalBookRepository.findAll();
		return digitalBooks.stream().filter(book -> book.getTitle().equalsIgnoreCase(title))
				.collect(Collectors.toList());
	}

	@Override
	public List<DigitalBook> searchDigitalBookByAuthor(String author) {
	 List<DigitalBook> digitalBooks = digitalBookRepository.findAll();
		return digitalBooks.stream().filter(book -> book.getAuthor().equalsIgnoreCase(author))
				.collect(Collectors.toList());
	}
	
	@Override
	public List<DigitalBook> searchDigitalBookByPrice(Double price) {
		List<DigitalBook> digitalBooks = digitalBookRepository.findAll();
		return digitalBooks.stream().filter(book -> book.getPrice().equals(price)).collect(Collectors.toList());
	}

	@Override
	public List<DigitalBook> searchDigitalBookByPublisher(String publisher) {
		List<DigitalBook> digitalBooks = digitalBookRepository.findAll();
		return digitalBooks.stream().filter(book -> book.getPublisher().equalsIgnoreCase(publisher))
				.collect(Collectors.toList());
	}

	@Override
	public List<DigitalBook> searchDigitalBookByCategory(String category) {
		List<DigitalBook> digitalBooks = digitalBookRepository.findAll();
		return digitalBooks.stream().filter(book -> book.getCategory().equalsIgnoreCase(category))
				.collect(Collectors.toList());
	}

	@Override
	public DigitalBook updateDigitalBook(DigitalBook book) {
		Optional<DigitalBook> digitalBookDb = digitalBookRepository.findById(book.getDigitalBookId());

		if (digitalBookDb.isPresent()) {
			DigitalBook bookUpdate = digitalBookDb.get();
			bookUpdate.setTitle(book.getTitle());
			bookUpdate.setCategory(book.getCategory());
			bookUpdate.setAuthor(book.getAuthor());
			bookUpdate.setPrice(book.getPrice());
			bookUpdate.setPublisher(book.getPublisher());
			bookUpdate.setContent(book.getContent());
			bookUpdate.setActive(book.getActive());
			return bookUpdate;
		} else {
			throw new RecordNotFoundException("Record not found!!");
		}
	}

	@Override
	public void deleteDigitalBook(int id) {

		Optional<DigitalBook> digitalBookDb = digitalBookRepository.findById(id);

		if (digitalBookDb.isPresent()) {
			digitalBookRepository.delete(digitalBookDb.get());
		} else {
			throw new RecordNotFoundException("Record not found!!");
		}

	}
//	@Override
//	public List<DigitalBook> subscribedDigitalBook(int id) {
//		List<int> digitalBookId=digitalBookRepository.findByUserId(id);
//		
//		List<DigitalBook> digitalBooks=new ArrayList<DigitalBook>();
//			Optional<DigitalBook> book=digitalBookRepository.findById(digitalBookId.get(id));
//			if(book.isPresent()) {
//				digitalBooks.add(book.get());
//			}
	/*
	 * else { throw new RecordNotFoundException("Record not found!!"); }
	 */
//
//		return digitalBooks;
//	}

}
