package com.digitalbook.Controller;

import java.util.List;

import com.digitalbook.entity.DigitalBook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.digitalbook.Service.DigitalBookService;

@RestController
@RequestMapping("/book")
public class DigitalBookController {
	@Autowired
	DigitalBookService digitalBookService;

	@PostMapping("/digitalBook")
	public ResponseEntity<DigitalBook> saveDigitalBook(@RequestBody DigitalBook book) {
		return ResponseEntity.ok().body(digitalBookService.saveDigitalBook(book));
	}

	@GetMapping("/digitalBook/{id}")
	public ResponseEntity<DigitalBook> getDigitalBookById(@PathVariable("id") int digitalBookId) {
		return ResponseEntity.ok().body(digitalBookService.getDigitalBookById(digitalBookId));
	}

	@GetMapping("/digitalBooks")
	public ResponseEntity<List<DigitalBook>> getAllDigitalBooks() {
		return ResponseEntity.ok().body(digitalBookService.getAllDigitalBooks());

	}

	@GetMapping("/search")
	public List<DigitalBook> searchDigitalBooks(@RequestParam("title") String title,
			@RequestParam("author") String author, @RequestParam("catogory") String category,
			@RequestParam("price") Double price, @RequestParam("Publisher") String publisher) {

		return digitalBookService.searchDigitalBooks(title, author, category, price, publisher);
	}

	@RequestMapping(value = "/{title}", method = RequestMethod.GET)
	public List<DigitalBook> searchDigitalBookByTitle(@RequestParam("title") String title) {
		return digitalBookService.searchDigitalBookByTitle(title);
	}

	@RequestMapping(value = "/{author}", method = RequestMethod.GET)
	public List<DigitalBook> searchDigitalBookByAuthor(@RequestParam("author") String author) {
		return digitalBookService.searchDigitalBookByAuthor(author);

	}
	
	@RequestMapping(value = "/{price}", method = RequestMethod.GET)
	public List<DigitalBook> searchDigitalBookByPrice(@RequestParam("price") Double price) {
		return digitalBookService.searchDigitalBookByPrice(price);

	}
	
	@RequestMapping(value = "/{publisher}", method = RequestMethod.GET)
	public List<DigitalBook> searchDigitalBookByPublisher(@RequestParam("publisher") String publisher) {
		return digitalBookService.searchDigitalBookByPublisher(publisher);

	}
	@RequestMapping(value = "/{category}", method = RequestMethod.GET)
	public List<DigitalBook> searchDigitalBookByCategory(@RequestParam("category") String category) {
		return digitalBookService.searchDigitalBookByCategory(category);

	}

	@PutMapping("/digitalBook/{id}")
	public ResponseEntity<DigitalBook> updateEmployee(@PathVariable int id, @RequestBody DigitalBook book) {
		book.setDigitalBookId(id);
		return ResponseEntity.ok().body(digitalBookService.updateDigitalBook(book));
	}

	@DeleteMapping("/digitalBook/{id}")
	public ResponseEntity<String> deleteDigitalBook(@PathVariable int id) {
		digitalBookService.deleteDigitalBook(id);
		return ResponseEntity.ok().body("Record Deleted");
	}

//	@GetMapping("/subscribe/{id}")
//	public List<DigitalBook> getData(@PathVariable int id){
//		return digitalBookService.subscribedDigitalBook(id);
//	}

}
