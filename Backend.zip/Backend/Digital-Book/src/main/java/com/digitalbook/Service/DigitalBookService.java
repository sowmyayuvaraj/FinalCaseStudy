package com.digitalbook.Service;

import com.digitalbook.entity.DigitalBook;
import com.digitalbook.entity.DigitalBook;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface DigitalBookService {
	public DigitalBook saveDigitalBook(DigitalBook book);

	public DigitalBook getDigitalBookById(int id);

	public List<DigitalBook> getAllDigitalBooks();

	public List<DigitalBook> searchDigitalBooks(String title, String author, String category, Double price,
			String publisher);

	public List<DigitalBook> searchDigitalBookByTitle(String title);
	
	public List<DigitalBook> searchDigitalBookByAuthor(String author);
	
	public List<DigitalBook> searchDigitalBookByPrice(Double price);

	public List<DigitalBook> searchDigitalBookByPublisher(String publisher);

	public List<DigitalBook> searchDigitalBookByCategory(String catogory);

	public DigitalBook updateDigitalBook(DigitalBook book);

	public void deleteDigitalBook(int id);

//	public List<DigitalBook> subscribedDigitalBook(int authorId);

}
