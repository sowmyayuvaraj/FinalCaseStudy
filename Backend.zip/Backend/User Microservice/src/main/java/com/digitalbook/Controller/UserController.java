package com.user.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.user.ReaderEntity.RegisterUser;
import com.user.ReaderService.RegisterUserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private RegisterUserService userService;

	@Autowired
	private RestTemplate restTemplate;

	@PostMapping("/signup")
	public String RegisterUser(@RequestBody RegisterUser user) {
		return userService.RegisterUser(user);
	}

	@PostMapping("/login")
	public RegisterUser LoginUser(@RequestBody RegisterUser user) {
		Optional<RegisterUser> users = userService.findUserByEmail(user.getEmail());
		if (users.isPresent()) {
			RegisterUser rs = users.get();
			if (rs.getPassword().equals(user.getPassword())) {
				return rs;
			}
		}
		return null;

	}

	@GetMapping("/getData/{id}")
	public Object getData(@PathVariable("id") Integer bookid) {
		Object records = restTemplate.getForObject("http://DigitalBook-Microservice/digitalBook/" + bookid,
				Object.class);

		return records;
	}

	@GetMapping("/getBooks")
	public Object getAllBooks() {
		Object records = restTemplate.getForObject("http://DigitalBook-Microservice/digitalBooks/", Object.class);

		return records;
	}

	@GetMapping("/searchBook")
	public Object searchBooks(@RequestParam("title") String title,
			@RequestParam("category") String category,
			@RequestParam("authorName") String authorName,
			@RequestParam("price") Double price,
			@RequestParam("Publisher") String publisher) {
		
		String url = "http://DigitalBook-Microservice/search?title={title}&category={category}&authorName={authorName}&price={price}&publisher={publisher}";
		
		Object records= restTemplate.getForObject(url,Object.class );	
		
				return records;
		
	}
	@GetMapping("/searchTitle/{title}")
	public Object searchBooksBytitle(@PathVariable String title) {

		String url = "http://DigitalBook-Microservice/title/";

		Object records = restTemplate.getForObject(url + title, Object.class);

		return records;

	}
	

	@GetMapping("/searchCategory/{cat}")
	public Object searchBooksBycategory(@PathVariable String cat) {

		String url = "http://DigitalBook-Microservice/category/";

		Object records = restTemplate.getForObject(url + cat, Object.class);

		return records;

	}

	@GetMapping("/searchAuthor/{author}")
	public Object searchBooksByAuthor(@PathVariable String author) {

		String url = "http://DigitalBook-Microservice/author/";

		Object records = restTemplate.getForObject(url + author, Object.class);

		return records;

	}

	@GetMapping("/searchPrice/{price}")
	public Object searchBooksByPrice(@PathVariable Double price) {

		String url = "http://books-microservice/price/";

		Object records = restTemplate.getForObject(url + price, Object.class);

		return records;

	}
	@GetMapping("/searchPublisher/{publisher}")
	public Object searchBooksBypublisher(@PathVariable String publisher) {

		String url = "http://DigitalBook-Microservice/publisher/";

		Object records = restTemplate.getForObject(url + publisher, Object.class);

		return records;

	}

}
