package com.user.ReaderService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.ReaderEntity.RegisterUser;
import com.user.Repository.RegisterUserRepository;

@Service
public class RegisterUserServiceImpl implements RegisterUserService {
	@Autowired
	private RegisterUserRepository userRepo;

	@Override
	public String RegisterUser(RegisterUser user) {
		
		RegisterUser saveUser=userRepo.save(user);
		return saveUser.getUserId();
	}

	@Override
	public Optional<RegisterUser> findUserByEmail(String userId) {
		RegisterUser saveUser=userRepo.findById(userId);
	   return  Optional.ofNullable(saveUser);
	}

}
