package com.user.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.user.ReaderEntity.Reader;
import com.user.ReaderService.ReaderService;

@RestController
@RequestMapping("/reader")
public class ReaderController {
	@Autowired
	private ReaderService readService;

	@Autowired
	private RestTemplate restTemplate;

	@PostMapping("/subscribe")
	public List<Reader> saveSubscribedBooks(@RequestBody List<Reader> subBook) {
		return readService.saveSubscribedBooks(subBook);
	}

	@GetMapping("/subscribedbooks")
	public List<Reader> getAllSubscribedBooks() {
		return readService.getAllSubscribedBooks();
	}

	@GetMapping("/search")
	public List searchDigitalBooks(@RequestParam("title") String title, @RequestParam("author") String author,
			@RequestParam("catogory") String category, @RequestParam("price") Double price,
			@RequestParam("Publisher") String publisher) {
		List book = this.restTemplate.getForObject(
				"http://localhost:8085/book/reader/search?title={title}&category={category}&authorName={authorName}&price={price}&publisher={publisher}",
				List.class);

		return book;
	}

	@GetMapping("/title")
	public List searchDigitalBookByTitle(@RequestParam("title") String title) {
		List book = this.restTemplate.getForObject("http://localhost:8085/book/reader/" + title, List.class);
		return book;
	}

	@GetMapping("/category")
	public List searchDigitalBookByCategory(@RequestParam("category") String category) {
		List book = this.restTemplate.getForObject("http://localhost:8085/book/reader/" + category, List.class);
		return book;
	}

	@GetMapping("/author")
	public List searchDigitalBookByAuthor(@RequestParam("author") String author) {
		List book = this.restTemplate.getForObject("http://localhost:8085/book/reader/" + author, List.class);
		return book;
	}

	@GetMapping("/price")
	public List searchDigitalBookByPrice(@RequestParam("price") String price) {
		List book = this.restTemplate.getForObject("http://localhost:8085/book/reader/" + price, List.class);
		return book;
	}

	@GetMapping("/publisher")
	public List searchDigitalBookByPublisher(@RequestParam("publisher") String publisher) {
		List book = this.restTemplate.getForObject("http://localhost:8085/book/reader/" + publisher, List.class);
		return book;
	}
}
