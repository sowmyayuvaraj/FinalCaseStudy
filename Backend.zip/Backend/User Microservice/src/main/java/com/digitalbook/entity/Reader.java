package com.digitalbook.entity;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
public class Reader {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public String subscriptionId;
    public String subscribeBook;
    public String subscriberName;
    public int digitalBookId;
    public String email;
    public String userIdfk;
    public String title;
    public String category;
    public String author;
    public Double price;
    public String publisher;

    @OneToMany
    List<DigitalBook> book = new ArrayList<>();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public Reader() {
        super();
        // TODO Auto-generated constructor stub
    }

    public Reader(String subscriptionId, String subscribeBook, String subscriberName, int digitalBookId, String email,
                  String userIdfk) {
        super();
        this.subscriptionId = subscriptionId;
        this.subscribeBook = subscribeBook;
        this.subscriberName = subscriberName;
        this.digitalBookId = digitalBookId;
        this.email = email;
        this.userIdfk = userIdfk;
    }

    public String getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(String subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public String getSubscribeBook() {
        return subscribeBook;
    }

    public void setSubscribeBook(String subscribeBook) {
        this.subscribeBook = subscribeBook;
    }

    public String getSubscriberName() {
        return subscriberName;
    }

    public void setSubscriberName(String subscriberName) {
        this.subscriberName = subscriberName;
    }

    public int getDigitalBookId() {
        return digitalBookId;
    }

    public void setDigitalBookId(int digitalBookId) {
        this.digitalBookId = digitalBookId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserIdfk() {
        return userIdfk;
    }

    public void setUserIdfk(String userId) {
        this.userIdfk = userId;
    }

    public List<DigitalBook> getBook() {
        return book;
    }

    public void setBook(List<DigitalBook> book) {
        this.book = book;
    }

}
