package com.user.ReaderService;

import java.util.List;

import com.user.ReaderEntity.Reader;

public interface ReaderService {
	
	public List<Reader> saveSubscribedBooks(List<Reader> subBook);
	
	public List<Reader> getAllSubscribedBooks();

	List<Reader> searchDigitalBooks(String title, String author, String category, Double price, String publisher);

	List<Reader> searchDigitalBookByTitle(String title);

	List<Reader> searchDigitalBookByAuthor(String author);

	List<Reader> searchDigitalBookByPrice(Double price);

	List<Reader> searchDigitalBookByPublisher(String publisher);

	List<Reader> searchDigitalBookByCategory(String category);

	

	

}
