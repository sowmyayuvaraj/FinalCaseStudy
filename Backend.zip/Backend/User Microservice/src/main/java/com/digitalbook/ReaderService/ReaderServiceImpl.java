package com.user.ReaderService;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.ReaderEntity.Reader;
import com.user.Repository.ReaderRepository;

@Service
public class ReaderServiceImpl implements ReaderService {

	@Autowired
	public ReaderRepository readRepo;

	@Override
	public List<Reader> saveSubscribedBooks(List<Reader> subBook) {

		return readRepo.saveAll(subBook);
	}

	@Override
	public List<Reader> getAllSubscribedBooks() {

		return readRepo.findAll();
	}

	@Override
	public List<Reader> searchDigitalBooks(String title, String author, String category, Double price,
			String publisher) {

		List<Reader> digitalBooks1 = readRepo.findAll();
		return digitalBooks1.stream()
				.filter(book -> book.getTitle().equalsIgnoreCase(title) || book.getCategory().equalsIgnoreCase(category)
						|| book.getAuthor().equalsIgnoreCase(author) || book.getPrice().equals(price)
						|| book.getPublisher().equalsIgnoreCase(publisher))
				.collect(Collectors.toList());
	}

	@Override
	public List<Reader> searchDigitalBookByTitle(String title) {
		List<Reader> digitalBooks1 = readRepo.findAll();
		return digitalBooks1.stream().filter(book -> book.getTitle().equalsIgnoreCase(title))
				.collect(Collectors.toList());
	}

	@Override
	public List<Reader> searchDigitalBookByAuthor(String author) {
		List<Reader> digitalBooks1 = readRepo.findAll();
		return digitalBooks1.stream().filter(book -> book.getAuthor().equalsIgnoreCase(author))
				.collect(Collectors.toList());
	}

	@Override
	public List<Reader> searchDigitalBookByPrice(Double price) {
		List<Reader> digitalBooks1 = readRepo.findAll();
		return digitalBooks1.stream().filter(book -> book.getPrice().equals(price)).collect(Collectors.toList());
	}

	@Override
	public List<Reader> searchDigitalBookByPublisher(String publisher) {
		List<Reader> digitalBooks1 = readRepo.findAll();
		return digitalBooks1.stream().filter(book -> book.getPublisher().equalsIgnoreCase(publisher))
				.collect(Collectors.toList());
	}

	@Override
	public List<Reader> searchDigitalBookByCategory(String category) {
		List<Reader> digitalBooks1 = readRepo.findAll();
		return digitalBooks1.stream().filter(book -> book.getCategory().equalsIgnoreCase(category))
				.collect(Collectors.toList());
	}

}
