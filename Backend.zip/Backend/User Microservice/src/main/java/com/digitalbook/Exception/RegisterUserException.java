package com.user.Exception;

public class RegisterUserException extends Throwable {

	private static final long serialVersionUID = -2703548874966055179L;
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public RegisterUserException(String message) {
		super();
		this.message = message;
	}
	

}
